/**
 * ============================================================
 * AURA ROAST & BREW — Application Core
 * Modular · Object-Oriented · Event-Delegated Architecture
 * ============================================================
 */

'use strict';

/* ------------------------------------------------------------
   1. STATE MANAGEMENT
   ------------------------------------------------------------ */
const AppState = {
  cart: JSON.parse(localStorage.getItem('aura_cart') || '[]'),
  reservations: JSON.parse(localStorage.getItem('aura_reservations') || '[]'),
  reviews: JSON.parse(localStorage.getItem('aura_reviews') || 'null') || [
    {
      id: 1,
      author: 'Elena V.',
      rating: 5,
      date: '2026-08-12',
      text: 'The single-origin Ethiopian pour-over is transcendental. Atmosphere of a private library meets the aroma of perfect roast.',
      tags: ['coffee', 'ambiance']
    },
    {
      id: 2,
      author: 'Marcus T.',
      rating: 5,
      date: '2026-07-28',
      text: 'Rooftop terrace at dusk with their signature latte — pure dark academia luxury. Service is impeccable.',
      tags: ['ambiance', 'service']
    },
    {
      id: 3,
      author: 'Sophia R.',
      rating: 4,
      date: '2026-07-15',
      text: 'Exceptional gluten-free options. The pistachio rose dessert is a masterpiece. Will return for the tasting flight.',
      tags: ['food', 'dessert']
    },
    {
      id: 4,
      author: 'James K.',
      rating: 5,
      date: '2026-06-30',
      text: 'Bean-to-cup transparency is rare. Their heritage timeline and sourcing story make every cup meaningful.',
      tags: ['coffee', 'heritage']
    },
    {
      id: 5,
      author: 'Aisha M.',
      rating: 4,
      date: '2026-06-18',
      text: 'Private Study zone is ideal for deep work. Quiet, elegant, and the cold brew is outstanding.',
      tags: ['ambiance', 'coffee']
    },
    {
      id: 6,
      author: 'Oliver P.',
      rating: 5,
      date: '2026-05-22',
      text: 'Artisanal breakfast board is worth the pilgrimage. Every element thoughtfully sourced and plated.',
      tags: ['food', 'breakfast']
    }
  ],
  currentMenuTier: 'coffees',
  filters: {
    priceMin: 0,
    priceMax: 50,
    caloriesMin: 0,
    caloriesMax: 800,
    dietary: []
  },
  soundscape: {
    active: null,
    context: null,
    sources: {}
  },
  isOpen: false
};

/* ------------------------------------------------------------
   2. MENU DATA
   ------------------------------------------------------------ */
const MenuData = {
  breakfast: [
    {
      id: 'b1',
      name: 'Heritage Breakfast Board',
      desc: 'House-cured salmon, soft scrambled eggs, sourdough, cultured butter, seasonal preserves.',
      price: 28,
      calories: 620,
      tags: ['organic'],
      emoji: '🥐',
      tier: 'breakfast'
    },
    {
      id: 'b2',
      name: 'Forest Mushroom Toast',
      desc: 'Wild mushrooms, crème fraîche, herbs, poached egg on ancient grain toast.',
      price: 22,
      calories: 480,
      tags: ['vegetarian', 'organic'],
      emoji: '🍄',
      tier: 'breakfast'
    },
    {
      id: 'b3',
      name: 'Golden Oat Porridge',
      desc: 'Steel-cut oats, saffron honey, toasted hazelnuts, freeze-dried berries.',
      price: 16,
      calories: 340,
      tags: ['vegan', 'gluten-free', 'organic'],
      emoji: '🥣',
      tier: 'breakfast'
    },
    {
      id: 'b4',
      name: 'Smoked Trout Benedict',
      desc: 'House-smoked trout, hollandaise, wilted greens, English muffin.',
      price: 26,
      calories: 580,
      tags: ['organic'],
      emoji: '🐟',
      tier: 'breakfast'
    }
  ],
  lunch: [
    {
      id: 'l1',
      name: 'Charred Octopus Salad',
      desc: 'Mediterranean octopus, bitter greens, citrus vinaigrette, fried capers.',
      price: 32,
      calories: 410,
      tags: ['gluten-free', 'organic'],
      emoji: '🐙',
      tier: 'lunch'
    },
    {
      id: 'l2',
      name: 'Truffle Mushroom Risotto',
      desc: 'Carnaroli rice, black truffle, aged parmesan, wild mushrooms.',
      price: 34,
      calories: 540,
      tags: ['vegetarian'],
      emoji: '🍚',
      tier: 'lunch'
    },
    {
      id: 'l3',
      name: 'Heritage Tomato Gazpacho',
      desc: 'Heirloom tomatoes, cucumber, basil oil, sourdough croutons.',
      price: 18,
      calories: 220,
      tags: ['vegan', 'organic'],
      emoji: '🍅',
      tier: 'lunch'
    },
    {
      id: 'l4',
      name: 'Duck Confit Sandwich',
      desc: 'Slow-cooked duck, cherry mostarda, arugula, brioche.',
      price: 29,
      calories: 680,
      tags: [],
      emoji: '🦆',
      tier: 'lunch'
    }
  ],
  coffees: [
    {
      id: 'c1',
      name: 'Ethiopian Single-Origin Pour-Over',
      desc: 'Yirgacheffe high-altitude beans. Jasmine, bergamot, honey notes. 200ml.',
      price: 12,
      calories: 5,
      tags: ['organic', 'vegan'],
      emoji: '☕',
      tier: 'coffees',
      customizable: true,
      basePrice: 12
    },
    {
      id: 'c2',
      name: 'Signature Aura Latte',
      desc: 'Double espresso, steamed milk, amber caramel dust, edible gold leaf.',
      price: 14,
      calories: 180,
      tags: ['vegetarian'],
      emoji: '✨',
      tier: 'coffees',
      customizable: true,
      basePrice: 14
    },
    {
      id: 'c3',
      name: 'Cold Brew Concentrate',
      desc: '18-hour steep. Bold, chocolate, low-acid. Served over crystal ice.',
      price: 11,
      calories: 10,
      tags: ['vegan', 'organic'],
      emoji: '🧊',
      tier: 'coffees',
      customizable: true,
      basePrice: 11
    },
    {
      id: 'c4',
      name: 'Espresso Flight',
      desc: 'Three single-origin espressos: Ethiopia, Colombia, Sumatra. Guided tasting.',
      price: 22,
      calories: 15,
      tags: ['organic', 'vegan'],
      emoji: '🔬',
      tier: 'coffees',
      customizable: false
    },
    {
      id: 'c5',
      name: 'Velvet Mocha',
      desc: 'House chocolate, double espresso, oat milk, toasted marshmallow.',
      price: 13,
      calories: 260,
      tags: ['vegetarian'],
      emoji: '🍫',
      tier: 'coffees',
      customizable: true,
      basePrice: 13
    },
    {
      id: 'c6',
      name: 'Spiced Moroccan Coffee',
      desc: 'Cardamom, cinnamon, rose water, traditional brass pot service.',
      price: 15,
      calories: 80,
      tags: ['vegan', 'organic'],
      emoji: '🌹',
      tier: 'coffees',
      customizable: false
    }
  ],
  desserts: [
    {
      id: 'd1',
      name: 'Pistachio Rose Gateau',
      desc: 'Layered pistachio sponge, rose cream, candied petals, gold leaf.',
      price: 16,
      calories: 420,
      tags: ['vegetarian'],
      emoji: '🌺',
      tier: 'desserts'
    },
    {
      id: 'd2',
      name: 'Dark Chocolate Sphère',
      desc: 'Valrhona 70%, liquid caramel core, sea salt, edible soil.',
      price: 18,
      calories: 480,
      tags: ['gluten-free', 'vegetarian'],
      emoji: '🌑',
      tier: 'desserts'
    },
    {
      id: 'd3',
      name: 'Olive Oil Citrus Cake',
      desc: 'Blood orange, rosemary, Sicilian olive oil, yogurt cream.',
      price: 14,
      calories: 360,
      tags: ['vegetarian', 'organic'],
      emoji: '🍊',
      tier: 'desserts'
    },
    {
      id: 'd4',
      name: 'Affogato Prestige',
      desc: 'House vanilla gelato drowned in single-origin espresso.',
      price: 12,
      calories: 280,
      tags: ['vegetarian', 'gluten-free'],
      emoji: '🍨',
      tier: 'desserts'
    }
  ]
};

/* ------------------------------------------------------------
   3. UTILITY MODULE
   ------------------------------------------------------------ */
const Utils = {
  formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 2
    }).format(amount);
  },

  formatDate(dateStr) {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  },

  generateId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  },

  debounce(fn, delay = 200) {
    let timer;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), delay);
    };
  },

  clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  },

  qs(selector, parent = document) {
    return parent.querySelector(selector);
  },

  qsa(selector, parent = document) {
    return Array.from(parent.querySelectorAll(selector));
  },

  createEl(tag, className = '', html = '') {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (html) el.innerHTML = html;
    return el;
  }
};

/* ------------------------------------------------------------
   4. STORAGE MODULE
   ------------------------------------------------------------ */
const Storage = {
  saveCart() {
    localStorage.setItem('aura_cart', JSON.stringify(AppState.cart));
  },

  saveReservations() {
    localStorage.setItem('aura_reservations', JSON.stringify(AppState.reservations));
  },

  saveReviews() {
    localStorage.setItem('aura_reviews', JSON.stringify(AppState.reviews));
  },

  clearAll() {
    localStorage.removeItem('aura_cart');
    localStorage.removeItem('aura_reservations');
    localStorage.removeItem('aura_reviews');
  }
};

/* ------------------------------------------------------------
   5. TOAST MODULE
   ------------------------------------------------------------ */
const Toast = {
  container: null,

  init() {
    this.container = Utils.qs('.toast-container');
    if (!this.container) {
      this.container = Utils.createEl('div', 'toast-container');
      document.body.appendChild(this.container);
    }
  },

  show(message, type = 'info', duration = 4000) {
    if (!this.container) this.init();

    const icons = {
      success: '✓',
      error: '✕',
      info: 'ⓘ'
    };

    const toast = Utils.createEl('div', `toast toast-${type}`);
    toast.innerHTML = `
      <span class="toast-icon">${icons[type] || icons.info}</span>
      <span class="toast-message">${message}</span>
      <button class="toast-close" aria-label="Close">×</button>
    `;

    this.container.appendChild(toast);

    requestAnimationFrame(() => {
      toast.classList.add('show');
    });

    const close = () => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    };

    toast.querySelector('.toast-close').addEventListener('click', close);
    setTimeout(close, duration);
  }
};

/* ------------------------------------------------------------
   6. NAVIGATION MODULE
   ------------------------------------------------------------ */
const Navigation = {
  header: null,
  mobileBtn: null,
  mobileNav: null,

  init() {
    this.header = Utils.qs('.site-header');
    this.mobileBtn = Utils.qs('.mobile-menu-btn');
    this.mobileNav = Utils.qs('.mobile-nav');

    this.bindScroll();
    this.bindMobile();
    this.setActiveLink();
    this.updateStatus();
    setInterval(() => this.updateStatus(), 60000);
  },

  bindScroll() {
    let lastScroll = 0;
    window.addEventListener('scroll', () => {
      const y = window.scrollY;
      if (this.header) {
        this.header.classList.toggle('scrolled', y > 40);
      }
      lastScroll = y;
    }, { passive: true });
  },

  bindMobile() {
    if (!this.mobileBtn || !this.mobileNav) return;

    this.mobileBtn.addEventListener('click', () => {
      const isOpen = this.mobileNav.classList.toggle('open');
      this.mobileBtn.classList.toggle('open', isOpen);
      this.mobileBtn.setAttribute('aria-expanded', isOpen);
      document.body.style.overflow = isOpen ? 'hidden' : '';
    });

    Utils.qsa('.mobile-nav .nav-link').forEach(link => {
      link.addEventListener('click', () => {
        this.mobileNav.classList.remove('open');
        this.mobileBtn.classList.remove('open');
        document.body.style.overflow = '';
      });
    });
  },

  setActiveLink() {
    const path = window.location.pathname.split('/').pop() || 'index.html';
    Utils.qsa('.nav-link').forEach(link => {
      const href = link.getAttribute('href');
      if (href === path || (path === '' && href === 'index.html')) {
        link.classList.add('active');
      }
    });
  },

  updateStatus() {
    const indicator = Utils.qs('.status-indicator');
    if (!indicator) return;

    const now = new Date();
    const hour = now.getHours();
    const day = now.getDay(); // 0 = Sun

    // Open: Tue–Sun 08:00–22:00, Closed Mondays
    const isOpen = day !== 1 && hour >= 8 && hour < 22;
    AppState.isOpen = isOpen;

    indicator.classList.toggle('open', isOpen);
    indicator.classList.toggle('closed', !isOpen);

    const text = indicator.querySelector('.status-text');
    if (text) {
      text.textContent = isOpen ? 'Open Now' : 'Closed';
    }
  }
};

/* ------------------------------------------------------------
   7. CART MODULE
   ------------------------------------------------------------ */
const Cart = {
  sidebar: null,
  overlay: null,

  init() {
    this.sidebar = Utils.qs('.cart-sidebar');
    this.createOverlay();
    this.bindTriggers();
    this.render();
  },

  createOverlay() {
    this.overlay = Utils.createEl('div', 'modal-overlay');
    this.overlay.style.zIndex = '350';
    this.overlay.addEventListener('click', () => this.close());
    document.body.appendChild(this.overlay);
  },

  bindTriggers() {
    document.addEventListener('click', (e) => {
      const openBtn = e.target.closest('[data-action="open-cart"]');
      const closeBtn = e.target.closest('[data-action="close-cart"]');
      const addBtn = e.target.closest('[data-action="add-to-cart"]');
      const removeBtn = e.target.closest('[data-action="remove-from-cart"]');
      const qtyPlus = e.target.closest('[data-action="qty-plus"]');
      const qtyMinus = e.target.closest('[data-action="qty-minus"]');
      const checkout = e.target.closest('[data-action="checkout"]');

      if (openBtn) this.open();
      if (closeBtn) this.close();
      if (addBtn) {
        const id = addBtn.dataset.id;
        const custom = addBtn.dataset.custom ? JSON.parse(addBtn.dataset.custom) : null;
        this.addItem(id, custom);
      }
      if (removeBtn) this.removeItem(removeBtn.dataset.cartId);
      if (qtyPlus) this.updateQty(qtyPlus.dataset.cartId, 1);
      if (qtyMinus) this.updateQty(qtyMinus.dataset.cartId, -1);
      if (checkout) this.checkout();
    });
  },

  open() {
    if (this.sidebar) this.sidebar.classList.add('open');
    if (this.overlay) this.overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  },

  close() {
    if (this.sidebar) this.sidebar.classList.remove('open');
    if (this.overlay) this.overlay.classList.remove('open');
    document.body.style.overflow = '';
  },

  findMenuItem(id) {
    for (const tier of Object.values(MenuData)) {
      const item = tier.find(i => i.id === id);
      if (item) return item;
    }
    return null;
  },

  addItem(id, custom = null) {
    const menuItem = this.findMenuItem(id);
    if (!menuItem) return;

    let price = menuItem.price;
    let meta = '';

    if (custom) {
      price = custom.price;
      meta = custom.meta;
    }

    const existing = AppState.cart.find(
      c => c.itemId === id && c.meta === meta
    );

    if (existing) {
      existing.qty += 1;
    } else {
      AppState.cart.push({
        cartId: Utils.generateId(),
        itemId: id,
        name: menuItem.name,
        price,
        qty: 1,
        meta,
        emoji: menuItem.emoji
      });
    }

    Storage.saveCart();
    this.render();
    this.updateBadge();
    Toast.show(`${menuItem.name} added to cart`, 'success');
  },

  removeItem(cartId) {
    AppState.cart = AppState.cart.filter(c => c.cartId !== cartId);
    Storage.saveCart();
    this.render();
    this.updateBadge();
  },

  updateQty(cartId, delta) {
    const item = AppState.cart.find(c => c.cartId === cartId);
    if (!item) return;

    item.qty += delta;
    if (item.qty <= 0) {
      this.removeItem(cartId);
      return;
    }

    Storage.saveCart();
    this.render();
    this.updateBadge();
  },

  getTotal() {
    return AppState.cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  },

  getCount() {
    return AppState.cart.reduce((sum, item) => sum + item.qty, 0);
  },

  updateBadge() {
    const badge = Utils.qs('.cart-badge');
    const count = this.getCount();
    if (badge) {
      badge.textContent = count;
      badge.style.display = count > 0 ? 'flex' : 'none';
    }
  },

  render() {
    const body = Utils.qs('.cart-body');
    const totalEl = Utils.qs('.cart-total-value');
    if (!body) return;

    if (AppState.cart.length === 0) {
      body.innerHTML = `
        <div class="cart-empty">
          <p style="font-size: 48px; margin-bottom: 16px;">☕</p>
          <p>Your cart is empty</p>
          <p class="fs-sm" style="margin-top: 8px;">Explore our menu to begin</p>
        </div>
      `;
    } else {
      body.innerHTML = AppState.cart.map(item => `
        <div class="cart-item">
          <div style="font-size: 28px;">${item.emoji || '☕'}</div>
          <div class="cart-item-info">
            <div class="cart-item-name">${item.name}</div>
            ${item.meta ? `<div class="cart-item-meta">${item.meta}</div>` : ''}
            <div class="cart-item-price">${Utils.formatCurrency(item.price)}</div>
          </div>
          <div class="cart-item-qty">
            <button class="qty-btn" data-action="qty-minus" data-cart-id="${item.cartId}">−</button>
            <span>${item.qty}</span>
            <button class="qty-btn" data-action="qty-plus" data-cart-id="${item.cartId}">+</button>
            <button class="qty-btn" data-action="remove-from-cart" data-cart-id="${item.cartId}" style="margin-left: 8px; color: #C47A7A;">×</button>
          </div>
        </div>
      `).join('');
    }

    if (totalEl) {
      totalEl.textContent = Utils.formatCurrency(this.getTotal());
    }

    this.updateBadge();
  },

  checkout() {
    if (AppState.cart.length === 0) {
      Toast.show('Your cart is empty', 'error');
      return;
    }

    const total = this.getTotal();
    AppState.cart = [];
    Storage.saveCart();
    this.render();
    this.close();
    Toast.show(`Order placed · ${Utils.formatCurrency(total)}. Thank you for choosing Aura.`, 'success', 5000);
  }
};

/* ------------------------------------------------------------
   8. MENU MODULE
   ------------------------------------------------------------ */
const Menu = {
  init() {
    this.bindTiers();
    this.bindFilters();
    this.render();
  },

  bindTiers() {
    Utils.qsa('.menu-tier-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        Utils.qsa('.menu-tier-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        AppState.currentMenuTier = btn.dataset.tier;
        this.render();
      });
    });
  },

  bindFilters() {
    const priceMin = Utils.qs('#filter-price-min');
    const priceMax = Utils.qs('#filter-price-max');
    const calMin = Utils.qs('#filter-cal-min');
    const calMax = Utils.qs('#filter-cal-max');
    const search = Utils.qs('#menu-search');

    const apply = Utils.debounce(() => {
      if (priceMin) AppState.filters.priceMin = Number(priceMin.value);
      if (priceMax) AppState.filters.priceMax = Number(priceMax.value);
      if (calMin) AppState.filters.caloriesMin = Number(calMin.value);
      if (calMax) AppState.filters.caloriesMax = Number(calMax.value);
      this.render();
    }, 150);

    [priceMin, priceMax, calMin, calMax].forEach(el => {
      if (el) el.addEventListener('input', apply);
    });

    if (search) {
      search.addEventListener('input', Utils.debounce(() => this.render(), 200));
    }

    Utils.qsa('[data-dietary]').forEach(chip => {
      chip.addEventListener('click', () => {
        chip.classList.toggle('active');
        const tag = chip.dataset.dietary;
        const idx = AppState.filters.dietary.indexOf(tag);
        if (idx === -1) {
          AppState.filters.dietary.push(tag);
        } else {
          AppState.filters.dietary.splice(idx, 1);
        }
        this.render();
      });
    });
  },

  getFilteredItems() {
    const tier = AppState.currentMenuTier;
    let items = MenuData[tier] || [];

    const searchEl = Utils.qs('#menu-search');
    const query = searchEl ? searchEl.value.toLowerCase().trim() : '';

    items = items.filter(item => {
      if (item.price < AppState.filters.priceMin || item.price > AppState.filters.priceMax) return false;
      if (item.calories < AppState.filters.caloriesMin || item.calories > AppState.filters.caloriesMax) return false;

      if (AppState.filters.dietary.length > 0) {
        const hasAll = AppState.filters.dietary.every(tag => item.tags.includes(tag));
        if (!hasAll) return false;
      }

      if (query) {
        const hay = `${item.name} ${item.desc}`.toLowerCase();
        if (!hay.includes(query)) return false;
      }

      return true;
    });

    return items;
  },

  render() {
    const grid = Utils.qs('.menu-grid');
    if (!grid) return;

    const items = this.getFilteredItems();

    if (items.length === 0) {
      grid.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; color: var(--cream-silk-50);">
          <p style="font-size: 40px; margin-bottom: 16px;">🔍</p>
          <p>No items match your filters</p>
        </div>
      `;
      return;
    }

    grid.innerHTML = items.map(item => {
      const tagsHtml = item.tags.map(t => {
        const cls = t === 'vegan' ? 'tag-vegan' : t === 'gluten-free' ? 'tag-gf' : t === 'organic' ? 'tag-organic' : '';
        const label = t === 'gluten-free' ? 'GF' : t.charAt(0).toUpperCase() + t.slice(1);
        return `<span class="tag ${cls}">${label}</span>`;
      }).join('');

      const actionBtn = item.customizable
        ? `<button class="btn btn-primary btn-sm" data-action="open-customizer" data-id="${item.id}">Customize</button>`
        : `<button class="btn btn-primary btn-sm" data-action="add-to-cart" data-id="${item.id}">Add</button>`;

      return `
        <article class="menu-item" data-id="${item.id}">
          <div class="menu-item-image">${item.emoji}</div>
          <div class="menu-item-body">
            <div class="menu-item-tags">${tagsHtml}</div>
            <h3 class="menu-item-name">${item.name}</h3>
            <p class="menu-item-desc">${item.desc}</p>
            <div class="menu-item-footer">
              <div>
                <div class="menu-item-price">${Utils.formatCurrency(item.price)}</div>
                <div class="menu-item-calories">${item.calories} kcal</div>
              </div>
              ${actionBtn}
            </div>
          </div>
        </article>
      `;
    }).join('');
  }
};

/* ------------------------------------------------------------
   9. CUSTOMIZER MODULE
   ------------------------------------------------------------ */
const Customizer = {
  currentItem: null,
  config: {
    shots: 2,
    milk: 'dairy',
    sweetness: 50,
    syrups: []
  },

  milkOptions: [
    { id: 'dairy', label: 'Dairy', price: 0 },
    { id: 'oat', label: 'Oat', price: 1.5 },
    { id: 'almond', label: 'Almond', price: 1.5 },
    { id: 'soy', label: 'Soy', price: 1 },
    { id: 'coconut', label: 'Coconut', price: 1.5 }
  ],

  syrupOptions: [
    { id: 'vanilla', label: 'Vanilla', price: 0.75 },
    { id: 'caramel', label: 'Caramel', price: 0.75 },
    { id: 'hazelnut', label: 'Hazelnut', price: 0.75 },
    { id: 'lavender', label: 'Lavender', price: 1 },
    { id: 'rose', label: 'Rose', price: 1 }
  ],

  init() {
    document.addEventListener('click', (e) => {
      const openBtn = e.target.closest('[data-action="open-customizer"]');
      const closeBtn = e.target.closest('[data-action="close-customizer"]');
      const addBtn = e.target.closest('[data-action="add-customized"]');

      if (openBtn) this.open(openBtn.dataset.id);
      if (closeBtn) this.close();
      if (addBtn) this.addToCart();
    });
  },

  open(itemId) {
    this.currentItem = Cart.findMenuItem(itemId);
    if (!this.currentItem) return;

    this.config = {
      shots: 2,
      milk: 'dairy',
      sweetness: 50,
      syrups: []
    };

    this.render();
    const overlay = Utils.qs('#customizer-modal');
    if (overlay) overlay.classList.add('open');
  },

  close() {
    const overlay = Utils.qs('#customizer-modal');
    if (overlay) overlay.classList.remove('open');
  },

  calculatePrice() {
    if (!this.currentItem) return 0;
    let price = this.currentItem.basePrice || this.currentItem.price;

    // Extra shots
    if (this.config.shots > 2) {
      price += (this.config.shots - 2) * 1.5;
    }

    // Milk
    const milk = this.milkOptions.find(m => m.id === this.config.milk);
    if (milk) price += milk.price;

    // Syrups
    this.config.syrups.forEach(sid => {
      const s = this.syrupOptions.find(x => x.id === sid);
      if (s) price += s.price;
    });

    return Math.round(price * 100) / 100;
  },

  getMeta() {
    const parts = [];
    parts.push(`${this.config.shots} shot${this.config.shots > 1 ? 's' : ''}`);
    const milk = this.milkOptions.find(m => m.id === this.config.milk);
    if (milk) parts.push(milk.label);
    if (this.config.sweetness !== 50) parts.push(`${this.config.sweetness}% sweet`);
    if (this.config.syrups.length) {
      const names = this.config.syrups.map(sid => {
        const s = this.syrupOptions.find(x => x.id === sid);
        return s ? s.label : sid;
      });
      parts.push(names.join(', '));
    }
    return parts.join(' · ');
  },

  render() {
    const body = Utils.qs('#customizer-body');
    const title = Utils.qs('#customizer-title');
    const priceEl = Utils.qs('#customizer-price');

    if (!body || !this.currentItem) return;

    if (title) title.textContent = this.currentItem.name;
    if (priceEl) priceEl.textContent = Utils.formatCurrency(this.calculatePrice());

    body.innerHTML = `
      <div class="customizer-section">
        <div class="customizer-section-title">Espresso Shots</div>
        <div class="shot-selector">
          ${[1, 2, 3, 4].map(n => `
            <button class="shot-btn ${this.config.shots === n ? 'active' : ''}" data-shots="${n}">${n}</button>
          `).join('')}
        </div>
      </div>

      <div class="customizer-section">
        <div class="customizer-section-title">Milk Base</div>
        <div class="radio-group">
          ${this.milkOptions.map(m => `
            <label class="radio-item ${this.config.milk === m.id ? 'active' : ''}">
              <input type="radio" name="milk" value="${m.id}" ${this.config.milk === m.id ? 'checked' : ''}>
              ${m.label}${m.price > 0 ? ` (+${Utils.formatCurrency(m.price)})` : ''}
            </label>
          `).join('')}
        </div>
      </div>

      <div class="customizer-section">
        <div class="customizer-section-title">Sweetness · <span id="sweetness-val">${this.config.sweetness}%</span></div>
        <input type="range" class="range-slider" id="sweetness-slider" min="0" max="100" step="10" value="${this.config.sweetness}">
      </div>

      <div class="customizer-section">
        <div class="customizer-section-title">Flavor Syrups</div>
        <div class="checkbox-group">
          ${this.syrupOptions.map(s => `
            <label class="checkbox-item ${this.config.syrups.includes(s.id) ? 'active' : ''}">
              <input type="checkbox" value="${s.id}" ${this.config.syrups.includes(s.id) ? 'checked' : ''}>
              ${s.label} (+${Utils.formatCurrency(s.price)})
            </label>
          `).join('')}
        </div>
      </div>
    `;

    // Bind interactions
    body.querySelectorAll('.shot-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        this.config.shots = Number(btn.dataset.shots);
        this.render();
      });
    });

    body.querySelectorAll('input[name="milk"]').forEach(input => {
      input.addEventListener('change', () => {
        this.config.milk = input.value;
        this.render();
      });
    });

    const slider = body.querySelector('#sweetness-slider');
    if (slider) {
      slider.addEventListener('input', () => {
        this.config.sweetness = Number(slider.value);
        const val = body.querySelector('#sweetness-val');
        if (val) val.textContent = `${this.config.sweetness}%`;
        if (priceEl) priceEl.textContent = Utils.formatCurrency(this.calculatePrice());
      });
    }

    body.querySelectorAll('.checkbox-item input').forEach(input => {
      input.addEventListener('change', () => {
        if (input.checked) {
          if (!this.config.syrups.includes(input.value)) {
            this.config.syrups.push(input.value);
          }
        } else {
          this.config.syrups = this.config.syrups.filter(s => s !== input.value);
        }
        this.render();
      });
    });
  },

  addToCart() {
    if (!this.currentItem) return;

    const price = this.calculatePrice();
    const meta = this.getMeta();

    Cart.addItem(this.currentItem.id, { price, meta });
    this.close();
  }
};

/* ------------------------------------------------------------
   10. REVIEWS MODULE
   ------------------------------------------------------------ */
const Reviews = {
  currentFilter: 'all',

  init() {
    this.bindFilters();
    this.bindForm();
    this.render();
  },

  bindFilters() {
    Utils.qsa('.filter-chip[data-review-filter]').forEach(chip => {
      chip.addEventListener('click', () => {
        Utils.qsa('.filter-chip[data-review-filter]').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        this.currentFilter = chip.dataset.reviewFilter;
        this.render();
      });
    });
  },

  bindForm() {
    const form = Utils.qs('#review-form');
    if (!form) return;

    let selectedRating = 0;

    Utils.qsa('#review-stars .star').forEach((star, idx) => {
      star.addEventListener('mouseenter', () => {
        Utils.qsa('#review-stars .star').forEach((s, i) => {
          s.classList.toggle('hover-filled', i <= idx);
        });
      });
      star.addEventListener('mouseleave', () => {
        Utils.qsa('#review-stars .star').forEach(s => s.classList.remove('hover-filled'));
      });
      star.addEventListener('click', () => {
        selectedRating = idx + 1;
        Utils.qsa('#review-stars .star').forEach((s, i) => {
          s.classList.toggle('filled', i < selectedRating);
        });
      });
    });

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = Utils.qs('#review-name')?.value.trim();
      const text = Utils.qs('#review-text')?.value.trim();

      if (!name || !text || selectedRating === 0) {
        Toast.show('Please complete all fields and select a rating', 'error');
        return;
      }

      AppState.reviews.unshift({
        id: Utils.generateId(),
        author: name,
        rating: selectedRating,
        date: new Date().toISOString().slice(0, 10),
        text,
        tags: ['general']
      });

      Storage.saveReviews();
      form.reset();
      selectedRating = 0;
      Utils.qsa('#review-stars .star').forEach(s => s.classList.remove('filled'));
      this.render();
      Toast.show('Thank you for your review', 'success');
    });
  },

  render() {
    const container = Utils.qs('#reviews-list');
    if (!container) return;

    let items = AppState.reviews;
    if (this.currentFilter !== 'all') {
      items = items.filter(r => r.tags.includes(this.currentFilter) || r.rating === Number(this.currentFilter));
    }

    container.innerHTML = items.map(r => `
      <article class="review-card">
        <div class="review-header">
          <div class="review-author">
            <div class="review-avatar">${r.author.charAt(0)}</div>
            <div>
              <div class="review-name">${r.author}</div>
              <div class="review-date">${Utils.formatDate(r.date)}</div>
            </div>
          </div>
          <div class="star-rating">
            ${[1, 2, 3, 4, 5].map(n => `
              <svg class="star ${n <= r.rating ? 'filled' : ''}" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
              </svg>
            `).join('')}
          </div>
        </div>
        <p class="review-body">${r.text}</p>
      </article>
    `).join('');
  }
};

/* ------------------------------------------------------------
   11. TIMELINE MODULE
   ------------------------------------------------------------ */
const Timeline = {
  init() {
    const items = Utils.qsa('.timeline-item');
    if (!items.length) return;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, { threshold: 0.4 });

    items.forEach(item => observer.observe(item));

    items.forEach(item => {
      const marker = item.querySelector('.timeline-marker');
      if (marker) {
        marker.addEventListener('click', () => {
          items.forEach(i => i.classList.remove('active'));
          item.classList.add('active');
          item.scrollIntoView({ behavior: 'smooth', block: 'center' });
        });
      }
    });
  }
};

/* ------------------------------------------------------------
   12. SOUNDSCAPE MODULE
   ------------------------------------------------------------ */
const Soundscape = {
  toggleBtn: null,
  panel: null,

  // Procedural ambient generators using Web Audio API
  generators: {
    rain: null,
    jazz: null,
    grinder: null
  },

  init() {
    this.toggleBtn = Utils.qs('.soundscape-toggle');
    this.panel = Utils.qs('.soundscape-panel');

    if (!this.toggleBtn) return;

    this.toggleBtn.addEventListener('click', () => {
      if (this.panel) {
        this.panel.classList.toggle('open');
      }
    });

    Utils.qsa('.sound-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const type = btn.dataset.sound;
        this.toggleSound(type, btn);
      });
    });
  },

  async ensureContext() {
    if (!AppState.soundscape.context) {
      AppState.soundscape.context = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (AppState.soundscape.context.state === 'suspended') {
      await AppState.soundscape.context.resume();
    }
    return AppState.soundscape.context;
  },

  createNoiseBuffer(ctx, duration = 2) {
    const sampleRate = ctx.sampleRate;
    const buffer = ctx.createBuffer(1, sampleRate * duration, sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    return buffer;
  },

  async startRain() {
    const ctx = await this.ensureContext();
    const buffer = this.createNoiseBuffer(ctx, 4);
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 800;

    const gain = ctx.createGain();
    gain.gain.value = 0.15;

    source.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    source.start();

    AppState.soundscape.sources.rain = { source, gain };
  },

  async startJazz() {
    const ctx = await this.ensureContext();
    // Soft chord-like tones
    const notes = [220, 277.18, 329.63, 415.3]; // A3, C#4, E4, G#4
    const sources = [];

    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = freq;

      const gain = ctx.createGain();
      gain.gain.value = 0.04;

      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.2 + i * 0.05;
      const lfoGain = ctx.createGain();
      lfoGain.gain.value = 0.01;
      lfo.connect(lfoGain);
      lfoGain.connect(gain.gain);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      lfo.start();
      sources.push({ osc, lfo, gain });
    });

    AppState.soundscape.sources.jazz = sources;
  },

  async startGrinder() {
    const ctx = await this.ensureContext();
    const buffer = this.createNoiseBuffer(ctx, 1);
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 1200;
    filter.Q.value = 2;

    const gain = ctx.createGain();
    gain.gain.value = 0.08;

    // Pulse the gain
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 8;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 0.04;
    lfo.connect(lfoGain);
    lfoGain.connect(gain.gain);

    source.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    source.start();
    lfo.start();

    AppState.soundscape.sources.grinder = { source, lfo, gain };
  },

  stopSound(type) {
    const src = AppState.soundscape.sources[type];
    if (!src) return;

    if (Array.isArray(src)) {
      src.forEach(s => {
        try { s.osc?.stop(); s.lfo?.stop(); } catch (_) {}
      });
    } else {
      try {
        src.source?.stop();
        src.lfo?.stop();
      } catch (_) {}
    }

    delete AppState.soundscape.sources[type];
  },

  async toggleSound(type, btn) {
    const isActive = AppState.soundscape.active === type;

    // Stop current
    if (AppState.soundscape.active) {
      this.stopSound(AppState.soundscape.active);
      Utils.qsa('.sound-btn').forEach(b => b.classList.remove('active'));
      AppState.soundscape.active = null;
    }

    if (!isActive) {
      if (type === 'rain') await this.startRain();
      else if (type === 'jazz') await this.startJazz();
      else if (type === 'grinder') await this.startGrinder();

      AppState.soundscape.active = type;
      btn.classList.add('active');
      if (this.toggleBtn) this.toggleBtn.classList.add('active');
      Toast.show(`Ambient: ${type}`, 'info', 2000);
    } else {
      if (this.toggleBtn) this.toggleBtn.classList.remove('active');
    }
  }
};

/* ------------------------------------------------------------
   13. PARALLAX MODULE
   ------------------------------------------------------------ */
const Parallax = {
  init() {
    const layers = Utils.qsa('.hero-bg-layer');
    if (!layers.length) return;

    window.addEventListener('scroll', () => {
      const scrolled = window.scrollY;
      layers.forEach((layer, i) => {
        const speed = (i + 1) * 0.15;
        layer.style.transform = `translateY(${scrolled * speed}px)`;
      });
    }, { passive: true });
  }
};

/* ------------------------------------------------------------
   14. SOURCING MAP MODULE
   ------------------------------------------------------------ */
const SourcingMap = {
  init() {
    Utils.qsa('.sourcing-step').forEach(step => {
      step.addEventListener('click', () => {
        Utils.qsa('.sourcing-step').forEach(s => s.classList.remove('active'));
        step.classList.add('active');

        const id = step.dataset.step;
        Utils.qsa('.sourcing-detail').forEach(d => {
          d.classList.toggle('active', d.dataset.detail === id);
        });
      });
    });
  }
};

/* ------------------------------------------------------------
   15. TEAM MODULE
   ------------------------------------------------------------ */
const Team = {
  init() {
    Utils.qsa('.team-card').forEach(card => {
      card.addEventListener('click', () => {
        const wasExpanded = card.classList.contains('expanded');
        Utils.qsa('.team-card').forEach(c => c.classList.remove('expanded'));
        if (!wasExpanded) {
          card.classList.add('expanded');
          // Animate metric bars
          card.querySelectorAll('.metric-fill').forEach(fill => {
            const width = fill.dataset.width || '70';
            fill.style.width = '0%';
            requestAnimationFrame(() => {
              fill.style.width = width + '%';
            });
          });
        }
      });
    });
  }
};

/* ------------------------------------------------------------
   16. RESERVATION MODULE
   ------------------------------------------------------------ */
const Reservation = {
  selectedZone: 'indoor',
  zones: {
    indoor: { name: 'Indoor Lounge', capacity: 40, available: 28 },
    rooftop: { name: 'Rooftop Terrace', capacity: 24, available: 12 },
    private: { name: 'Private Study', capacity: 8, available: 5 }
  },

  init() {
    this.bindZones();
    this.bindForm();
    this.updateOccupancy();
  },

  bindZones() {
    Utils.qsa('.zone-card').forEach(card => {
      card.addEventListener('click', () => {
        Utils.qsa('.zone-card').forEach(c => c.classList.remove('active'));
        card.classList.add('active');
        this.selectedZone = card.dataset.zone;
        this.updateOccupancy();
      });
    });
  },

  updateOccupancy() {
    const zone = this.zones[this.selectedZone];
    const el = Utils.qs('#occupancy-value');
    const label = Utils.qs('#occupancy-label');
    if (el) el.textContent = `${zone.available} / ${zone.capacity}`;
    if (label) label.textContent = `${zone.name} availability`;
  },

  bindForm() {
    const form = Utils.qs('#reservation-form');
    if (!form) return;

    const guestsInput = Utils.qs('#res-guests');
    if (guestsInput) {
      guestsInput.addEventListener('input', () => {
        const val = Number(guestsInput.value);
        const zone = this.zones[this.selectedZone];
        if (val > zone.available) {
          guestsInput.setCustomValidity(`Only ${zone.available} seats available in this zone`);
        } else {
          guestsInput.setCustomValidity('');
        }
      });
    }

    form.addEventListener('submit', (e) => {
      e.preventDefault();

      const name = Utils.qs('#res-name')?.value.trim();
      const email = Utils.qs('#res-email')?.value.trim();
      const date = Utils.qs('#res-date')?.value;
      const time = Utils.qs('#res-time')?.value;
      const guests = Number(Utils.qs('#res-guests')?.value);

      if (!name || !email || !date || !time || !guests) {
        Toast.show('Please complete all reservation fields', 'error');
        return;
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        Toast.show('Please enter a valid email address', 'error');
        return;
      }

      const zone = this.zones[this.selectedZone];
      if (guests > zone.available) {
        Toast.show(`Only ${zone.available} seats available in ${zone.name}`, 'error');
        return;
      }

      AppState.reservations.push({
        id: Utils.generateId(),
        name,
        email,
        date,
        time,
        guests,
        zone: this.selectedZone,
        zoneName: zone.name,
        status: 'pending',
        created: new Date().toISOString()
      });

      // Simulate availability reduction
      zone.available = Math.max(0, zone.available - guests);
      this.updateOccupancy();

      Storage.saveReservations();
      form.reset();
      Toast.show(`Table reserved · ${zone.name} · ${date} at ${time}`, 'success', 5000);
    });
  }
};

/* ------------------------------------------------------------
   17. CONTACT FORM MODULE
   ------------------------------------------------------------ */
const ContactForm = {
  init() {
    const form = Utils.qs('#contact-form');
    if (!form) return;

    const message = Utils.qs('#contact-message');
    const counter = Utils.qs('#char-counter');

    if (message && counter) {
      message.addEventListener('input', () => {
        const len = message.value.length;
        const max = 500;
        counter.textContent = `${len} / ${max}`;
        counter.classList.toggle('warning', len > 400);
        counter.classList.toggle('error', len >= max);
      });
    }

    form.addEventListener('submit', (e) => {
      e.preventDefault();

      const name = Utils.qs('#contact-name')?.value.trim();
      const email = Utils.qs('#contact-email')?.value.trim();
      const subject = Utils.qs('#contact-subject')?.value.trim();
      const msg = message?.value.trim();

      const errors = [];

      if (!name || name.length < 2) errors.push('Name must be at least 2 characters');
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('Valid email required');
      if (!subject || subject.length < 3) errors.push('Subject required');
      if (!msg || msg.length < 10) errors.push('Message must be at least 10 characters');
      if (msg && msg.length > 500) errors.push('Message exceeds 500 characters');

      if (errors.length) {
        Toast.show(errors[0], 'error');
        return;
      }

      form.reset();
      if (counter) counter.textContent = '0 / 500';
      Toast.show('Message sent. We will respond within 24 hours.', 'success');
    });
  }
};

/* ------------------------------------------------------------
   18. ADMIN MODULE
   ------------------------------------------------------------ */
const Admin = {
  init() {
    this.renderStats();
    this.renderOrders();
    this.renderReservations();
  },

  renderStats() {
    const revenue = AppState.cart.reduce((s, i) => s + i.price * i.qty, 0);
    // Simulate some base revenue from stored data patterns
    const baseRevenue = 1840 + (AppState.reservations.length * 45);
    const totalRevenue = baseRevenue + revenue;

    const elRevenue = Utils.qs('#stat-revenue');
    const elOrders = Utils.qs('#stat-orders');
    const elReservations = Utils.qs('#stat-reservations');
    const elAvg = Utils.qs('#stat-avg');

    if (elRevenue) elRevenue.textContent = Utils.formatCurrency(totalRevenue);
    if (elOrders) elOrders.textContent = AppState.cart.length + 12;
    if (elReservations) elReservations.textContent = AppState.reservations.length;
    if (elAvg) {
      const avg = AppState.cart.length
        ? revenue / AppState.cart.reduce((s, i) => s + i.qty, 0)
        : 24;
      elAvg.textContent = Utils.formatCurrency(avg || 24);
    }
  },

  renderOrders() {
    const container = Utils.qs('#admin-orders');
    if (!container) return;

    if (AppState.cart.length === 0) {
      container.innerHTML = `<div class="admin-row"><span style="color: var(--cream-silk-50);">No active cart items</span></div>`;
      return;
    }

    container.innerHTML = AppState.cart.map(item => `
      <div class="admin-row">
        <div>
          <strong>${item.name}</strong>
          <div class="fs-xs text-muted">${item.meta || 'Standard'} · Qty ${item.qty}</div>
        </div>
        <div style="text-align: right;">
          <div>${Utils.formatCurrency(item.price * item.qty)}</div>
          <span class="admin-row-status status-pending">In Cart</span>
        </div>
      </div>
    `).join('');
  },

  renderReservations() {
    const container = Utils.qs('#admin-reservations');
    if (!container) return;

    if (AppState.reservations.length === 0) {
      container.innerHTML = `<div class="admin-row"><span style="color: var(--cream-silk-50);">No pending reservations</span></div>`;
      return;
    }

    container.innerHTML = AppState.reservations.map(r => `
      <div class="admin-row">
        <div>
          <strong>${r.name}</strong>
          <div class="fs-xs text-muted">${r.zoneName} · ${r.date} ${r.time} · ${r.guests} guests</div>
        </div>
        <span class="admin-row-status status-${r.status}">${r.status}</span>
      </div>
    `).join('');
  }
};

/* ------------------------------------------------------------
   19. APPLICATION BOOTSTRAP
   ------------------------------------------------------------ */
const App = {
  init() {
    // Core
    Navigation.init();
    Cart.init();
    Toast.init();

    // Page-specific
    const page = document.body.dataset.page;

    if (page === 'home') {
      Parallax.init();
      Timeline.init();
      Soundscape.init();
      Reviews.init();
    }

    if (page === 'menu') {
      Menu.init();
      Customizer.init();
    }

    if (page === 'about') {
      SourcingMap.init();
      Team.init();
    }

    if (page === 'contact') {
      Reservation.init();
      ContactForm.init();
    }

    if (page === 'admin') {
      Admin.init();
    }

    // Global customizer bind (for menu page)
    Customizer.init();
  }
};

// Boot
document.addEventListener('DOMContentLoaded', () => App.init());
